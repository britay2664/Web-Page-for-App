package gymtracker;

/*******************************************************************
 * Name: Brian Taylor
 * Date: August 8, 2026
 * Assignment: SDC330 Project Week 2
 *
 * Purpose:
 * This class represents a general exercise in the Gym Progress
 * Tracker. It serves as the base class for more specific exercise
 * types and stores information that all exercises share.
 *******************************************************************/

public class Exercise {

    private String name;
    private String muscleGroup;

    // Constructor
    public Exercise(String name, String muscleGroup) {
        this.name = name;
        this.muscleGroup = muscleGroup;
    }

    // Getters
    public String getName() {
        return name;
    }

    public String getMuscleGroup() {
        return muscleGroup;
    }

    // Setters
    public void setName(String name) {
        this.name = name;
    }

    public void setMuscleGroup(String muscleGroup) {
        this.muscleGroup = muscleGroup;
    }

    // Display exercise information directly to the console
    public void displayInformation() {
        System.out.println("Exercise: " + name);
        System.out.println("Muscle Group: " + muscleGroup);
    }

    // Return formatted exercise information
    @Override
    public String toString() {
        return String.format(
                "Exercise: %s%n"
                        + "Muscle Group: %s",
                name,
                muscleGroup
        );
    }
}