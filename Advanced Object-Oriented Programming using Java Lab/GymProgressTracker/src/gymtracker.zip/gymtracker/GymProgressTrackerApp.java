package gymtracker;

import java.util.Scanner;

/*
 * Name: Brian Taylor
 * Date: August 1, 2026
 * Purpose: This class starts the Week 1 Gym Progress Tracker,
 * creates realistic objects, displays the user interface,
 * and accepts basic menu input from the user.
 */

public class GymProgressTrackerApp {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        /*
         * These objects demonstrate inheritance because
         * StrengthExercise and CardioExercise are child
         * classes of Exercise.
         */
        StrengthExercise benchPress = new StrengthExercise(
                "Bench Press",
                "Chest",
                4,
                10,
                225.0);

        StrengthExercise tricepsPushdown = new StrengthExercise(
                "Triceps Pushdown",
                "Triceps",
                4,
                15,
                80.0);

        CardioExercise stairMaster = new CardioExercise(
                "StairMaster",
                "Cardiovascular System",
                15,
                0.8);

        /*
         * This object demonstrates composition because the
         * WorkoutSession contains Exercise objects.
         */
        WorkoutSession sampleWorkout = new WorkoutSession(
                "August 1, 2026",
                "Chest, Triceps, and Cardio");

        sampleWorkout.addExercise(benchPress);
        sampleWorkout.addExercise(tricepsPushdown);
        sampleWorkout.addExercise(stairMaster);

        int selection;

        displayHeading();
        displayWelcomeMessage();

        do {
            displayMenu();

            System.out.print("Enter your selection: ");

            while (!input.hasNextInt()) {
                System.out.println();
                System.out.println("Invalid entry. Please enter a menu number.");
                input.next();
                System.out.print("Enter your selection: ");
            }

            selection = input.nextInt();

            System.out.println();

            switch (selection) {
                case 1:
                    displayUserProfile();
                    break;

                case 2:
                    displayAvailableExercises(
                            benchPress,
                            tricepsPushdown,
                            stairMaster);
                    break;

                case 3:
                    sampleWorkout.displayWorkout();
                    break;

                case 4:
                    displayProgramInformation();
                    break;

                case 0:
                    System.out.println(
                            "Thank you for using the Gym Progress Tracker!");
                    System.out.println(
                            "Stay consistent and keep making progress!");
                    break;

                default:
                    System.out.println(
                            "Invalid selection. Please choose 0 through 4.");
                    break;
            }

        } while (selection != 0);

        input.close();
    }

    public static void displayHeading() {
        System.out.println("==================================================");
        System.out.println("PROJECT WEEK 1");
        System.out.println("ADVANCED OBJECT-ORIENTED PROGRAMMING USING JAVA");
        System.out.println("GYM PROGRESS TRACKER");
        System.out.println("Developed by Brian Taylor");
        System.out.println("==================================================");
    }

    public static void displayWelcomeMessage() {
        System.out.println();
        System.out.println("Welcome to the Gym Progress Tracker!");
        System.out.println(
                "This Week 1 application demonstrates basic");
        System.out.println(
                "user interaction, inheritance, and composition.");
        System.out.println(
                "Enter the number beside an option to make a selection.");
    }

    public static void displayMenu() {
        System.out.println();
        System.out.println("---------------- Main Menu ----------------");
        System.out.println("1. Display User Profile");
        System.out.println("2. Display Available Exercises");
        System.out.println("3. Display Sample Workout Session");
        System.out.println("4. Display Program Information");
        System.out.println("0. Exit");
        System.out.println("-------------------------------------------");
    }

    public static void displayUserProfile() {
        System.out.println("--------------- User Profile ---------------");
        System.out.println("Name: Brian Taylor");
        System.out.println("Primary Goal: Improve strength and conditioning");
        System.out.println("Experience Level: Intermediate");
        System.out.println("--------------------------------------------");
    }

    public static void displayAvailableExercises(
            Exercise firstExercise,
            Exercise secondExercise,
            Exercise thirdExercise) {

        System.out.println("------------ Available Exercises ------------");

        firstExercise.displayInformation();
        System.out.println();

        secondExercise.displayInformation();
        System.out.println();

        thirdExercise.displayInformation();

        System.out.println("---------------------------------------------");
    }

    public static void displayProgramInformation() {
        System.out.println("------------ Program Information ------------");
        System.out.println(
                "The Gym Progress Tracker will allow users to");
        System.out.println(
                "record workouts and monitor fitness progress.");
        System.out.println();
        System.out.println(
                "Inheritance: Exercise is the base class.");
        System.out.println(
                "StrengthExercise and CardioExercise are child classes.");
        System.out.println();
        System.out.println(
                "Composition: WorkoutSession contains Exercise objects.");
        System.out.println("---------------------------------------------");
    }
}