package gymtracker;

/*******************************************************************
 * Name: Brian Taylor
 * Date: August 8, 2026
 * Assignment: SDC330 Project Week 2
 *
 * Purpose:
 * This class represents a cardio exercise in the Gym Progress
 * Tracker. It inherits common exercise information from the
 * Exercise class and implements the ProgressTrackable interface.
 *******************************************************************/

public class CardioExercise extends Exercise
        implements ProgressTrackable {

    private int durationMinutes;
    private double distanceMiles;

    // Constructor
    public CardioExercise(
            String name,
            String muscleGroup,
            int durationMinutes,
            double distanceMiles) {

        super(name, muscleGroup);

        this.durationMinutes = durationMinutes;
        this.distanceMiles = distanceMiles;
    }

    // Getters
    public int getDurationMinutes() {
        return durationMinutes;
    }

    public double getDistanceMiles() {
        return distanceMiles;
    }

    // Setters
    public void setDurationMinutes(int durationMinutes) {
        this.durationMinutes = durationMinutes;
    }

    public void setDistanceMiles(double distanceMiles) {
        this.distanceMiles = distanceMiles;
    }

    /*
     * INTERFACE IMPLEMENTATION:
     * This method is required by ProgressTrackable.
     */
    @Override
    public String getProgressSummary() {
        return String.format(
                "%s Progress: %d minutes covering %.2f miles",
                getName(),
                durationMinutes,
                distanceMiles
        );
    }

    @Override
    public String toString() {
        return String.format(
                "%s%n"
                        + "Duration: %d minutes%n"
                        + "Distance: %.2f miles",
                super.toString(),
                durationMinutes,
                distanceMiles
        );
    }
}