package gymtracker;

/*******************************************************************
 * Name: Brian Taylor
 * Date: August 8, 2026
 * Assignment: SDC330 Project Week 2
 *
 * Purpose:
 * This class represents a strength-training exercise in the Gym
 * Progress Tracker. It inherits common exercise information from
 * the Exercise class and implements the ProgressTrackable interface.
 *******************************************************************/

public class StrengthExercise extends Exercise
        implements ProgressTrackable {

    private int sets;
    private int reps;
    private double weight;

    // Constructor
    public StrengthExercise(
            String name,
            String muscleGroup,
            int sets,
            int reps,
            double weight) {

        super(name, muscleGroup);

        this.sets = sets;
        this.reps = reps;
        this.weight = weight;
    }

    // Getters
    public int getSets() {
        return sets;
    }

    public int getReps() {
        return reps;
    }

    public double getWeight() {
        return weight;
    }

    // Setters
    public void setSets(int sets) {
        this.sets = sets;
    }

    public void setReps(int reps) {
        this.reps = reps;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    /*
     * INTERFACE IMPLEMENTATION:
     * This method is required by ProgressTrackable.
     */
    @Override
    public String getProgressSummary() {
        return String.format(
                "%s Progress: %d sets x %d reps at %.1f lbs",
                getName(),
                sets,
                reps,
                weight
        );
    }

    @Override
    public String toString() {
        return String.format(
                "%s%n"
                        + "Sets: %d%n"
                        + "Reps: %d%n"
                        + "Weight: %.1f lbs",
                super.toString(),
                sets,
                reps,
                weight
        );
    }
}